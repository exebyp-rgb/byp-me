import { useState } from "react";

const THEMES = {
  bold: {
    name: "Bold & Strong",
    desc: "Dark, powerful — for electricians",
    primary: "#1a1a2e",
    accent: "#e94560",
    card: "#16213e",
    text: "#ffffff",
    sub: "#a0aec0",
    badge: "#e94560",
  },
  clean: {
    name: "Clean & Trusted",
    desc: "White, minimal — for plumbers",
    primary: "#f7f9fc",
    accent: "#2563eb",
    card: "#ffffff",
    text: "#1a202c",
    sub: "#64748b",
    badge: "#2563eb",
  },
  warm: {
    name: "Warm & Local",
    desc: "Family business feel",
    primary: "#1c1410",
    accent: "#d97706",
    card: "#2a1f16",
    text: "#fef3c7",
    sub: "#d6b896",
    badge: "#d97706",
  },
  premium: {
    name: "Premium Pro",
    desc: "For top-tier contractors",
    primary: "#0a0a0a",
    accent: "#c9a84c",
    card: "#141414",
    text: "#f5f0e8",
    sub: "#9a8a70",
    badge: "#c9a84c",
  },
};

const TRADES = ["Electrician", "Plumber", "HVAC", "General Contractor", "Carpenter", "Painter"];

const DEFAULT_ITEMS = [
  { id: 1, description: "", qty: 1, unit: "job", price: "" },
];

function generateId() {
  return Math.random().toString(36).substr(2, 9);
}

export default function ProBid() {
  const [step, setStep] = useState("form"); // form | preview | pdf
  const [theme, setTheme] = useState("bold");
  const [loading, setLoading] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState(null);
  const [showAiModal, setShowAiModal] = useState(false);

  const [form, setForm] = useState({
    businessName: "",
    masterName: "",
    trade: "Electrician",
    phone: "",
    email: "",
    license: "",
    tagline: "",
    clientName: "",
    clientAddress: "",
    clientPhone: "",
    projectDesc: "",
    items: DEFAULT_ITEMS,
    warranty: "1 year on all labor",
    deposit: "50% deposit required to schedule",
    validDays: "7",
    notes: "",
  });

  const t = THEMES[theme];

  const updateForm = (key, val) => setForm((f) => ({ ...f, [key]: val }));

  const updateItem = (id, key, val) => {
    setForm((f) => ({
      ...f,
      items: f.items.map((item) => (item.id === id ? { ...item, [key]: val } : item)),
    }));
  };

  const addItem = () => {
    setForm((f) => ({
      ...f,
      items: [...f.items, { id: generateId(), description: "", qty: 1, unit: "job", price: "" }],
    }));
  };

  const removeItem = (id) => {
    setForm((f) => ({ ...f, items: f.items.filter((i) => i.id !== id) }));
  };

  const subtotal = form.items.reduce((sum, i) => sum + (parseFloat(i.price) || 0) * (parseFloat(i.qty) || 1), 0);
  const tax = subtotal * 0.08;
  const total = subtotal + tax;

  const askAI = async () => {
    setLoading(true);
    try {
      const prompt = `You are an assistant for a ${form.trade} contractor named "${form.businessName || "the contractor"}".

They described their project as: "${form.projectDesc}"

Current line items they entered:
${form.items.map((i) => `- ${i.description || "(no description)"}: $${i.price} x ${i.qty}`).join("\n")}

Your job:
1. Improve/complete any vague line item descriptions to sound professional
2. If any prices are missing or seem too low for the US market, suggest realistic prices
3. Suggest a short powerful tagline for their business if they don't have one
4. Write a short, warm, confident closing note for the quote (2 sentences max)

Respond ONLY in this JSON format, no markdown:
{
  "items": [{"description": "...", "price": 123, "qty": 1, "unit": "job"}],
  "tagline": "...",
  "closingNote": "..."
}`;

      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          messages: [{ role: "user", content: prompt }],
        }),
      });
      const data = await response.json();
      const text = data.content.map((c) => c.text || "").join("");
      const clean = text.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      setAiSuggestion(parsed);
      setShowAiModal(true);
    } catch (e) {
      alert("AI error. Please try again.");
    }
    setLoading(false);
  };

  const applyAI = () => {
    if (!aiSuggestion) return;
    setForm((f) => ({
      ...f,
      tagline: aiSuggestion.tagline || f.tagline,
      notes: aiSuggestion.closingNote || f.notes,
      items: aiSuggestion.items.map((i, idx) => ({
        id: f.items[idx]?.id || generateId(),
        description: i.description,
        price: i.price,
        qty: i.qty || 1,
        unit: i.unit || "job",
      })),
    }));
    setShowAiModal(false);
  };

  const today = new Date().toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
  const validUntil = new Date(Date.now() + parseInt(form.validDays || 7) * 86400000).toLocaleDateString("en-US", {
    month: "long", day: "numeric", year: "numeric",
  });
  const quoteNum = "Q-" + Date.now().toString().slice(-6);

  const styles = `
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600&family=Playfair+Display:wght@700&family=Syne:wght@700;800&display=swap');
    
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body {
      font-family: 'DM Sans', sans-serif;
      background: ${t.primary};
      color: ${t.text};
      min-height: 100vh;
    }

    .app { max-width: 860px; margin: 0 auto; padding: 24px 16px 80px; }

    .header {
      text-align: center;
      padding: 40px 0 32px;
      border-bottom: 1px solid ${t.accent}33;
      margin-bottom: 36px;
    }

    .logo {
      font-family: 'Bebas Neue', sans-serif;
      font-size: 52px;
      letter-spacing: 4px;
      color: ${t.accent};
      line-height: 1;
    }

    .logo-sub {
      font-size: 13px;
      letter-spacing: 6px;
      text-transform: uppercase;
      color: ${t.sub};
      margin-top: 6px;
    }

    .theme-picker {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
      justify-content: center;
      margin-top: 24px;
    }

    .theme-btn {
      padding: 8px 16px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 600;
      letter-spacing: 1px;
      text-transform: uppercase;
      cursor: pointer;
      border: 1.5px solid transparent;
      transition: all 0.2s;
    }

    .section {
      background: ${t.card};
      border-radius: 12px;
      padding: 28px;
      margin-bottom: 20px;
      border: 1px solid ${t.accent}22;
    }

    .section-title {
      font-family: 'Syne', sans-serif;
      font-size: 11px;
      letter-spacing: 4px;
      text-transform: uppercase;
      color: ${t.accent};
      margin-bottom: 20px;
    }

    .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
    .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 14px; }

    label {
      display: block;
      font-size: 11px;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: ${t.sub};
      margin-bottom: 6px;
    }

    input, select, textarea {
      width: 100%;
      background: ${t.primary};
      border: 1px solid ${t.accent}33;
      color: ${t.text};
      padding: 10px 14px;
      border-radius: 8px;
      font-family: 'DM Sans', sans-serif;
      font-size: 14px;
      outline: none;
      transition: border-color 0.2s;
    }

    input:focus, select:focus, textarea:focus {
      border-color: ${t.accent};
    }

    select option { background: ${t.primary}; }

    textarea { resize: vertical; min-height: 80px; }

    .field { margin-bottom: 14px; }

    .items-header {
      display: grid;
      grid-template-columns: 3fr 80px 100px 120px 40px;
      gap: 8px;
      font-size: 10px;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: ${t.sub};
      padding-bottom: 10px;
      border-bottom: 1px solid ${t.accent}22;
      margin-bottom: 12px;
    }

    .item-row {
      display: grid;
      grid-template-columns: 3fr 80px 100px 120px 40px;
      gap: 8px;
      margin-bottom: 8px;
      align-items: center;
    }

    .remove-btn {
      background: none;
      border: none;
      color: ${t.sub};
      font-size: 18px;
      cursor: pointer;
      padding: 0;
      line-height: 1;
      transition: color 0.2s;
    }
    .remove-btn:hover { color: #e94560; }

    .add-btn {
      background: none;
      border: 1.5px dashed ${t.accent}55;
      color: ${t.accent};
      padding: 10px;
      border-radius: 8px;
      width: 100%;
      cursor: pointer;
      font-size: 13px;
      font-weight: 600;
      margin-top: 8px;
      transition: all 0.2s;
    }
    .add-btn:hover { border-color: ${t.accent}; background: ${t.accent}11; }

    .totals {
      margin-top: 20px;
      padding-top: 20px;
      border-top: 1px solid ${t.accent}33;
    }

    .total-row {
      display: flex;
      justify-content: space-between;
      padding: 4px 0;
      font-size: 14px;
      color: ${t.sub};
    }

    .total-final {
      display: flex;
      justify-content: space-between;
      padding: 12px 0 4px;
      font-size: 22px;
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      color: ${t.accent};
      border-top: 1px solid ${t.accent}44;
      margin-top: 8px;
    }

    .ai-btn {
      width: 100%;
      padding: 16px;
      background: linear-gradient(135deg, ${t.accent}22, ${t.accent}44);
      border: 1.5px solid ${t.accent};
      color: ${t.accent};
      border-radius: 10px;
      font-family: 'Syne', sans-serif;
      font-size: 14px;
      font-weight: 700;
      letter-spacing: 2px;
      text-transform: uppercase;
      cursor: pointer;
      margin-bottom: 12px;
      transition: all 0.2s;
    }
    .ai-btn:hover { background: ${t.accent}; color: ${t.primary}; }
    .ai-btn:disabled { opacity: 0.5; cursor: not-allowed; }

    .preview-btn {
      width: 100%;
      padding: 18px;
      background: ${t.accent};
      border: none;
      color: ${theme === "clean" ? "#ffffff" : t.primary};
      border-radius: 10px;
      font-family: 'Syne', sans-serif;
      font-size: 15px;
      font-weight: 800;
      letter-spacing: 3px;
      text-transform: uppercase;
      cursor: pointer;
      transition: all 0.2s;
    }
    .preview-btn:hover { transform: translateY(-1px); box-shadow: 0 8px 24px ${t.accent}44; }

    /* Modal */
    .modal-overlay {
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.85);
      display: flex; align-items: center; justify-content: center;
      z-index: 1000; padding: 20px;
    }

    .modal {
      background: ${t.card};
      border: 1px solid ${t.accent}44;
      border-radius: 16px;
      padding: 32px;
      max-width: 560px;
      width: 100%;
      max-height: 80vh;
      overflow-y: auto;
    }

    .modal-title {
      font-family: 'Syne', sans-serif;
      font-size: 20px;
      font-weight: 800;
      color: ${t.accent};
      margin-bottom: 8px;
    }

    .modal-desc {
      font-size: 13px;
      color: ${t.sub};
      margin-bottom: 24px;
      line-height: 1.6;
    }

    .suggestion-item {
      background: ${t.primary};
      border-radius: 8px;
      padding: 12px 16px;
      margin-bottom: 8px;
      border-left: 3px solid ${t.accent};
    }

    .suggestion-label {
      font-size: 10px;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: ${t.accent};
      margin-bottom: 4px;
    }

    .suggestion-val { font-size: 14px; color: ${t.text}; }

    .modal-actions { display: flex; gap: 12px; margin-top: 24px; }

    .btn-approve {
      flex: 1; padding: 14px;
      background: ${t.accent}; border: none;
      color: ${theme === "clean" ? "#fff" : t.primary};
      border-radius: 8px;
      font-family: 'Syne', sans-serif;
      font-size: 13px; font-weight: 800;
      letter-spacing: 2px; text-transform: uppercase;
      cursor: pointer;
    }

    .btn-cancel {
      padding: 14px 20px;
      background: none; border: 1px solid ${t.accent}44;
      color: ${t.sub};
      border-radius: 8px;
      font-size: 13px; cursor: pointer;
    }

    /* PDF Preview */
    .pdf-wrap {
      background: #f7f9fc;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    }

    .pdf-top {
      background: ${t.accent};
      padding: 36px 40px;
      color: ${theme === "clean" ? "#ffffff" : t.primary};
    }

    .pdf-biz-name {
      font-family: ${theme === "warm" ? "'Playfair Display'" : "'Bebas Neue'"}, sans-serif;
      font-size: ${theme === "warm" ? "32px" : "44px"};
      letter-spacing: ${theme === "warm" ? "1px" : "4px"};
      line-height: 1;
    }

    .pdf-tagline {
      font-size: 13px;
      opacity: 0.85;
      margin-top: 6px;
      font-style: ${theme === "warm" ? "italic" : "normal"};
    }

    .pdf-body { padding: 36px 40px; background: #ffffff; color: #1a202c; }

    .pdf-meta {
      display: flex;
      justify-content: space-between;
      margin-bottom: 32px;
      padding-bottom: 24px;
      border-bottom: 2px solid ${t.accent};
    }

    .pdf-meta-block h4 {
      font-size: 10px;
      letter-spacing: 3px;
      text-transform: uppercase;
      color: #94a3b8;
      margin-bottom: 8px;
    }

    .pdf-meta-block p { font-size: 14px; color: #1a202c; line-height: 1.7; }

    .pdf-items { width: 100%; border-collapse: collapse; margin-bottom: 24px; }

    .pdf-items th {
      font-size: 10px;
      letter-spacing: 2px;
      text-transform: uppercase;
      color: #94a3b8;
      text-align: left;
      padding: 8px 12px;
      border-bottom: 1px solid #e2e8f0;
    }

    .pdf-items td {
      padding: 12px 12px;
      font-size: 14px;
      color: #1a202c;
      border-bottom: 1px solid #f1f5f9;
    }

    .pdf-items tr:last-child td { border-bottom: none; }

    .pdf-totals {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 28px;
    }

    .pdf-totals-inner { width: 260px; }

    .pdf-total-row {
      display: flex;
      justify-content: space-between;
      padding: 5px 0;
      font-size: 13px;
      color: #64748b;
    }

    .pdf-total-final {
      display: flex;
      justify-content: space-between;
      padding: 12px 0 0;
      border-top: 2px solid ${t.accent};
      font-size: 20px;
      font-weight: 700;
      color: ${t.accent};
      margin-top: 8px;
    }

    .pdf-terms {
      background: #f8fafc;
      border-radius: 10px;
      padding: 20px 24px;
      margin-bottom: 24px;
    }

    .pdf-terms h4 {
      font-size: 10px;
      letter-spacing: 3px;
      text-transform: uppercase;
      color: #94a3b8;
      margin-bottom: 12px;
    }

    .pdf-terms p {
      font-size: 13px;
      color: #475569;
      line-height: 1.7;
      margin-bottom: 4px;
    }

    .pdf-footer {
      background: ${t.accent};
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: ${theme === "clean" ? "#ffffff" : t.primary};
      font-size: 12px;
      opacity: 0.95;
    }

    .back-btn {
      background: none;
      border: 1.5px solid ${t.accent}55;
      color: ${t.sub};
      padding: 12px 24px;
      border-radius: 8px;
      cursor: pointer;
      font-size: 13px;
      margin-bottom: 16px;
      transition: all 0.2s;
    }
    .back-btn:hover { border-color: ${t.accent}; color: ${t.accent}; }

    .print-btn {
      width: 100%;
      padding: 18px;
      background: ${t.accent};
      border: none;
      color: ${theme === "clean" ? "#ffffff" : t.primary};
      border-radius: 10px;
      font-family: 'Syne', sans-serif;
      font-size: 15px;
      font-weight: 800;
      letter-spacing: 3px;
      text-transform: uppercase;
      cursor: pointer;
      margin-top: 20px;
      transition: all 0.2s;
    }
    .print-btn:hover { transform: translateY(-1px); box-shadow: 0 8px 24px ${t.accent}44; }

    .badge {
      display: inline-block;
      background: ${t.accent}22;
      color: ${t.accent};
      padding: 3px 10px;
      border-radius: 20px;
      font-size: 11px;
      font-weight: 600;
      letter-spacing: 1px;
    }

    @media (max-width: 600px) {
      .grid-2, .grid-3 { grid-template-columns: 1fr; }
      .items-header, .item-row { grid-template-columns: 2fr 60px 100px 30px; }
      .items-header > *:nth-child(3), .item-row > *:nth-child(3) { display: none; }
    }

    @media print {
      body { background: white !important; }
      .app { padding: 0; }
      .back-btn, .print-btn, .header, .section { display: none; }
      .pdf-wrap { box-shadow: none; border-radius: 0; }
    }
  `;

  if (step === "preview") {
    return (
      <>
        <style>{styles}</style>
        <div className="app">
          <div style={{ marginBottom: 20 }}>
            <button className="back-btn" onClick={() => setStep("form")}>← Back to Edit</button>
          </div>

          <div className="pdf-wrap" id="pdf-content">
            <div className="pdf-top">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <div className="pdf-biz-name">{form.businessName || "YOUR BUSINESS"}</div>
                  {form.tagline && <div className="pdf-tagline">{form.tagline}</div>}
                  <div style={{ marginTop: 12, fontSize: 13, opacity: 0.8 }}>
                    {form.trade} {form.license && `· License #${form.license}`}
                  </div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 28, fontFamily: "'Bebas Neue'", letterSpacing: 2 }}>ESTIMATE</div>
                  <div style={{ fontSize: 13, opacity: 0.8 }}>{quoteNum}</div>
                </div>
              </div>
            </div>

            <div className="pdf-body">
              <div className="pdf-meta">
                <div className="pdf-meta-block">
                  <h4>Prepared for</h4>
                  <p>
                    <strong>{form.clientName || "Client Name"}</strong><br />
                    {form.clientAddress && <>{form.clientAddress}<br /></>}
                    {form.clientPhone}
                  </p>
                </div>
                <div className="pdf-meta-block">
                  <h4>Contact</h4>
                  <p>
                    {form.masterName}<br />
                    {form.phone}<br />
                    {form.email}
                  </p>
                </div>
                <div className="pdf-meta-block" style={{ textAlign: "right" }}>
                  <h4>Date</h4>
                  <p>{today}</p>
                  <div style={{ marginTop: 8 }}>
                    <h4>Valid until</h4>
                    <p>{validUntil}</p>
                  </div>
                </div>
              </div>

              {form.projectDesc && (
                <div style={{ marginBottom: 24, padding: "16px 20px", background: "#f8fafc", borderRadius: 8, borderLeft: `4px solid ${t.accent}` }}>
                  <div style={{ fontSize: 10, letterSpacing: 3, textTransform: "uppercase", color: "#94a3b8", marginBottom: 6 }}>Project Description</div>
                  <p style={{ fontSize: 14, color: "#475569", lineHeight: 1.7 }}>{form.projectDesc}</p>
                </div>
              )}

              <table className="pdf-items">
                <thead>
                  <tr>
                    <th>Description</th>
                    <th>Qty</th>
                    <th>Unit</th>
                    <th style={{ textAlign: "right" }}>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {form.items.filter(i => i.description).map((item) => (
                    <tr key={item.id}>
                      <td>{item.description}</td>
                      <td>{item.qty}</td>
                      <td>{item.unit}</td>
                      <td style={{ textAlign: "right", fontWeight: 600 }}>
                        ${((parseFloat(item.price) || 0) * (parseFloat(item.qty) || 1)).toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="pdf-totals">
                <div className="pdf-totals-inner">
                  <div className="pdf-total-row"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
                  <div className="pdf-total-row"><span>Tax (8%)</span><span>${tax.toFixed(2)}</span></div>
                  <div className="pdf-total-final"><span>TOTAL</span><span>${total.toFixed(2)}</span></div>
                </div>
              </div>

              <div className="pdf-terms">
                <h4>Terms & Conditions</h4>
                {form.deposit && <p>💳 {form.deposit}</p>}
                {form.warranty && <p>🛡️ Warranty: {form.warranty}</p>}
                <p>📅 This estimate is valid for {form.validDays} days from the date above.</p>
              </div>

              {form.notes && (
                <div style={{ padding: "16px 20px", borderRadius: 8, background: "#f8fafc", fontStyle: "italic", fontSize: 14, color: "#64748b", lineHeight: 1.7 }}>
                  {form.notes}
                </div>
              )}
            </div>

            <div className="pdf-footer">
              <span>{form.businessName} · {form.trade}</span>
              <span>{form.phone} · {form.email}</span>
              <span style={{ opacity: 0.7 }}>Powered by ProBid</span>
            </div>
          </div>

          <button className="print-btn" onClick={() => window.print()}>
            ⬇ Download / Print PDF
          </button>
        </div>
      </>
    );
  }

  return (
    <>
      <style>{styles}</style>
      <div className="app">
        <div className="header">
          <div className="logo">PROBID</div>
          <div className="logo-sub">Professional Estimates for Trade Contractors</div>

          <div className="theme-picker">
            {Object.entries(THEMES).map(([key, th]) => (
              <button
                key={key}
                className="theme-btn"
                onClick={() => setTheme(key)}
                style={{
                  background: theme === key ? th.accent : "transparent",
                  borderColor: th.accent,
                  color: theme === key ? (key === "clean" ? "#fff" : t.primary) : th.accent,
                }}
              >
                {th.name}
              </button>
            ))}
          </div>
        </div>

        {/* Your Business */}
        <div className="section">
          <div className="section-title">Your Business</div>
          <div className="grid-2">
            <div className="field">
              <label>Business Name</label>
              <input value={form.businessName} onChange={e => updateForm("businessName", e.target.value)} placeholder="Mike's Electric Co." />
            </div>
            <div className="field">
              <label>Your Name</label>
              <input value={form.masterName} onChange={e => updateForm("masterName", e.target.value)} placeholder="Mike Johnson" />
            </div>
          </div>
          <div className="grid-3">
            <div className="field">
              <label>Trade</label>
              <select value={form.trade} onChange={e => updateForm("trade", e.target.value)}>
                {TRADES.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div className="field">
              <label>Phone</label>
              <input value={form.phone} onChange={e => updateForm("phone", e.target.value)} placeholder="(555) 000-0000" />
            </div>
            <div className="field">
              <label>License #</label>
              <input value={form.license} onChange={e => updateForm("license", e.target.value)} placeholder="EC-12345" />
            </div>
          </div>
          <div className="field">
            <label>Email</label>
            <input value={form.email} onChange={e => updateForm("email", e.target.value)} placeholder="mike@mikeelectric.com" type="email" />
          </div>
          <div className="field">
            <label>Your Tagline <span className="badge">AI can suggest</span></label>
            <input value={form.tagline} onChange={e => updateForm("tagline", e.target.value)} placeholder="Trusted. Licensed. Done Right." />
          </div>
        </div>

        {/* Client */}
        <div className="section">
          <div className="section-title">Client Info</div>
          <div className="grid-2">
            <div className="field">
              <label>Client Name</label>
              <input value={form.clientName} onChange={e => updateForm("clientName", e.target.value)} placeholder="John & Sarah Smith" />
            </div>
            <div className="field">
              <label>Client Phone</label>
              <input value={form.clientPhone} onChange={e => updateForm("clientPhone", e.target.value)} placeholder="(555) 111-2222" />
            </div>
          </div>
          <div className="field">
            <label>Project Address</label>
            <input value={form.clientAddress} onChange={e => updateForm("clientAddress", e.target.value)} placeholder="123 Oak Street, Austin TX 78701" />
          </div>
          <div className="field">
            <label>Project Description <span className="badge">AI will improve</span></label>
            <textarea value={form.projectDesc} onChange={e => updateForm("projectDesc", e.target.value)} placeholder="e.g. Replace panel box, add 3 outlets in garage, install outdoor lighting..." />
          </div>
        </div>

        {/* Line Items */}
        <div className="section">
          <div className="section-title">Work Items <span className="badge">AI can fill prices</span></div>
          <div className="items-header">
            <span>Description</span>
            <span>Qty</span>
            <span>Unit</span>
            <span>Price ($)</span>
            <span></span>
          </div>
          {form.items.map((item) => (
            <div className="item-row" key={item.id}>
              <input value={item.description} onChange={e => updateItem(item.id, "description", e.target.value)} placeholder="Panel box replacement" />
              <input type="number" value={item.qty} onChange={e => updateItem(item.id, "qty", e.target.value)} min="1" />
              <select value={item.unit} onChange={e => updateItem(item.id, "unit", e.target.value)}>
                {["job","hr","ft","unit","ea"].map(u => <option key={u}>{u}</option>)}
              </select>
              <input type="number" value={item.price} onChange={e => updateItem(item.id, "price", e.target.value)} placeholder="0.00" />
              <button className="remove-btn" onClick={() => removeItem(item.id)}>×</button>
            </div>
          ))}
          <button className="add-btn" onClick={addItem}>+ Add Line Item</button>

          <div className="totals">
            <div className="total-row"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
            <div className="total-row"><span>Tax (8%)</span><span>${tax.toFixed(2)}</span></div>
            <div className="total-final"><span>TOTAL</span><span>${total.toFixed(2)}</span></div>
          </div>
        </div>

        {/* Terms */}
        <div className="section">
          <div className="section-title">Terms</div>
          <div className="grid-2">
            <div className="field">
              <label>Payment Terms</label>
              <input value={form.deposit} onChange={e => updateForm("deposit", e.target.value)} placeholder="50% deposit required" />
            </div>
            <div className="field">
              <label>Valid for (days)</label>
              <input type="number" value={form.validDays} onChange={e => updateForm("validDays", e.target.value)} />
            </div>
          </div>
          <div className="field">
            <label>Warranty</label>
            <input value={form.warranty} onChange={e => updateForm("warranty", e.target.value)} placeholder="1 year on all labor" />
          </div>
          <div className="field">
            <label>Closing Note <span className="badge">AI can write</span></label>
            <textarea value={form.notes} onChange={e => updateForm("notes", e.target.value)} placeholder="Thank you for the opportunity. I take pride in every job I complete..." />
          </div>
        </div>

        {/* AI + Preview */}
        <button className="ai-btn" onClick={askAI} disabled={loading}>
          {loading ? "⚡ AI is thinking..." : "⚡ AI — Improve My Quote"}
        </button>
        <button className="preview-btn" onClick={() => setStep("preview")}>
          Preview & Download PDF →
        </button>

        {/* AI Approval Modal */}
        {showAiModal && aiSuggestion && (
          <div className="modal-overlay">
            <div className="modal">
              <div className="modal-title">⚡ AI Suggestions Ready</div>
              <div className="modal-desc">Review what AI wants to improve. You decide what gets applied.</div>

              {aiSuggestion.tagline && (
                <div className="suggestion-item">
                  <div className="suggestion-label">Tagline</div>
                  <div className="suggestion-val">"{aiSuggestion.tagline}"</div>
                </div>
              )}

              {aiSuggestion.items?.map((item, i) => (
                <div className="suggestion-item" key={i}>
                  <div className="suggestion-label">Line {i + 1}</div>
                  <div className="suggestion-val">{item.description} — <strong>${item.price}</strong></div>
                </div>
              ))}

              {aiSuggestion.closingNote && (
                <div className="suggestion-item">
                  <div className="suggestion-label">Closing Note</div>
                  <div className="suggestion-val">"{aiSuggestion.closingNote}"</div>
                </div>
              )}

              <div className="modal-actions">
                <button className="btn-approve" onClick={applyAI}>✓ Apply All</button>
                <button className="btn-cancel" onClick={() => setShowAiModal(false)}>Cancel</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
